<form method="post" enctype="multipart/form-data" action="/leads/upload">
    <input type="file" name="file" />
    <button type="submit">Upload</button>
</form>