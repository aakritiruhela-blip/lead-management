<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('test-db', 'LeadController::testDb');

$routes->get('leads', 'LeadController::index');
$routes->put('leads/(:num)', 'LeadController::update/$1');

$routes->post('leads/upload', 'LeadController::upload');
$routes->post('leads/preview', 'LeadController::preview');
$routes->post('leads/upload-final', 'LeadController::uploadFinal');
