<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\LeadModel;
use PhpOffice\PhpSpreadsheet\IOFactory;


class LeadController extends BaseController
{

public function testDb()
{
    try {
        $db = \Config\Database::connect();
        $query = $db->query("SELECT NOW() AS current_time");
        $result = $query->getRow();
        return $this->response->setJSON($result);
    } catch (\Exception $e) {
        return $this->response->setJSON([
            'error' => $e->getMessage()
        ]);
    }
}


public function index()
{
    $model = new LeadModel();

    $query = $model->orderBy('updated_date', 'DESC');

    $status = $this->request->getGet('status');
    $enquiry = $this->request->getGet('enquiry_for');
    $agent = $this->request->getGet('agent_name');

    if ($status) {
        $query->where('status', $status);
    }

    if ($enquiry) {
        $query->where('enquiry_for', $enquiry);
    }

    if ($agent) {
        $query->where('agent_name', $agent);
    }

    $data = $query->findAll();

    return $this->response->setJSON($data);
}

public function update($id)
{
    $model = new LeadModel();
    $data = $this->request->getJSON(true);

    if ($data['status'] === 'rejected' && empty($data['rejection_reason'])) {
        return $this->response->setJSON([
            'error' => 'Rejection reason is required'
        ])->setStatusCode(400);
    }

    $existing = $model
        ->where('mobile_number', $data['mobile_number'])
        ->where('id !=', $id)
        ->first();

    if ($existing) {
        return $this->response->setJSON([
            'error' => 'Mobile number already exists'
        ])->setStatusCode(400);
    }

    $model->update($id, $data);

    return $this->response->setJSON([
        'message' => 'Lead updated successfully'
    ]);
}
// public function upload()
// {
//     $file = $this->request->getFile('file');

//     if (!$file->isValid()) {
//         return $this->response->setJSON(['error' => 'Invalid file'])->setStatusCode(400);
//     }

//     $spreadsheet = IOFactory::load($file->getTempName());
//     $sheet = $spreadsheet->getActiveSheet();
//     $rows = $sheet->toArray();

//     $headers = $rows[0];

//     return $this->response->setJSON([
//         'file_columns' => $headers,
//         'system_fields' => [
//             'customer_name',
//             'mobile_number',
//             'enquiry_for',
//             'status',
//             'rejection_reason',
//             'agent_id',
//             'agent_name'
//         ]
//     ]);
// }

public function upload()
{
    $file = $this->request->getFile('file');

    if (!$file || !$file->isValid()) {
        return $this->response->setJSON([
            'error' => 'Invalid file'
        ])->setStatusCode(400);
    }

    // Create uploads directory if not exists
    $uploadPath = WRITEPATH . 'uploads/';
    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0777, true);
    }

    // Generate unique filename
    $newName = time() . '_' . $file->getRandomName();
    $file->move($uploadPath, $newName);

    $fullPath = $uploadPath . $newName;

    $spreadsheet = IOFactory::load($fullPath);
    $rows = $spreadsheet->getActiveSheet()->toArray();

    $headers = $rows[0];

    return $this->response->setJSON([
        'file_token' => $newName, // IMPORTANT
        'file_columns' => $headers,
        'system_fields' => [
            'customer_name',
            'mobile_number',
            'enquiry_for',
            'status',
            'rejection_reason',
            'agent_id',
            'agent_name'
        ]
    ]);
}


// public function preview()
// {
//     $mapping = $this->request->getPost('mapping');
//     $filePath = WRITEPATH . 'uploads/temp.csv';

//     $spreadsheet = IOFactory::load($filePath);
//     $rows = $spreadsheet->getActiveSheet()->toArray();

//     $headers = $rows[0];
//     $preview = [];
//     $errors = [];

//     foreach ($rows as $index => $row) {
//         if ($index === 0) continue;

//         $lead = [];

//         foreach ($mapping as $sysField => $fileCol) {
//             $colIndex = array_search($fileCol, $headers);
//             $lead[$sysField] = $row[$colIndex] ?? null;
//         }

//         if (
//             empty($lead['customer_name']) ||
//             empty($lead['mobile_number']) ||
//             empty($lead['enquiry_for'])
//         ) {
//             $errors[] = $lead;
//         } else {
//             $preview[] = $lead;
//         }
//     }

//     return $this->response->setJSON([
//         'preview' => $preview,
//         'errors' => $errors
//     ]);
// }


public function preview()
{
    $requestData = $this->request->getJSON(true);

    $mapping = $requestData['mapping'] ?? [];
    $fileToken = $requestData['file_token'] ?? null;

    if (!$fileToken) {
        return $this->response->setJSON([
            'error' => 'File token missing'
        ])->setStatusCode(400);
    }

    $filePath = WRITEPATH . 'uploads/' . $fileToken;

    if (!file_exists($filePath)) {
        return $this->response->setJSON([
            'error' => 'Uploaded file not found'
        ])->setStatusCode(404);
    }

    $spreadsheet = IOFactory::load($filePath);
    $rows = $spreadsheet->getActiveSheet()->toArray();

    $headers = $rows[0];
    $preview = [];
    $errors = [];

    $model = new LeadModel();

    foreach ($rows as $index => $row) {
        if ($index === 0) continue;

        $lead = [];

        foreach ($mapping as $sysField => $fileCol) {
            $colIndex = array_search($fileCol, $headers);
            $lead[$sysField] = $colIndex !== false ? $row[$colIndex] : null;
        }

        // Mandatory validation
        if (
            empty($lead['customer_name']) ||
            empty($lead['mobile_number']) ||
            empty($lead['enquiry_for'])
        ) {
            $lead['error'] = 'Missing mandatory fields';
            $errors[] = $lead;
            continue;
        }

        // Status validation
        if (!in_array($lead['status'], ['pending', 'approved', 'rejected'])) {
            $lead['error'] = 'Invalid status';
            $errors[] = $lead;
            continue;
        }

        // Duplicate check
        if ($model->where('mobile_number', $lead['mobile_number'])->first()) {
            $lead['warning'] = 'Duplicate mobile number';
        }

        $preview[] = $lead;
    }

    return $this->response->setJSON([
        'preview' => $preview,
        'errors' => $errors
    ]);
}


public function uploadFinal()
{
    $model = new LeadModel();
    $data = $this->request->getJSON(true);

    $inserted = 0;
    $updated = 0;

    foreach ($data as $lead) {

        if ($lead['status'] === 'rejected' && empty($lead['rejection_reason'])) {
            continue;
        }

        $existing = $model
            ->where('mobile_number', $lead['mobile_number'])
            ->first();

        if ($existing) {
            $model->update($existing['id'], $lead);
            $updated++;
        } else {
            $lead['leadId'] = 'LD' . date('Ymd') . '-' . rand(100, 999);
            $model->insert($lead);
            $inserted++;
        }
    }

    return $this->response->setJSON([
        'inserted' => $inserted,
        'updated' => $updated
    ]);
}


}
