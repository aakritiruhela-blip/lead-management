let uploadedFileToken = null;
let fileColumns = [];
let systemFields = [];

document.getElementById('uploadForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const formData = new FormData();
    formData.append('file', document.getElementById('fileInput').files[0]);

    const res = await fetch('/leads/upload', {
        method: 'POST',
        body: formData
    });

    const data = await res.json();

    fileColumns = data.file_columns;
    systemFields = data.system_fields;
    uploadedFileToken = data.file_token;

    renderMapping();
});

function renderMapping() {
    const form = document.getElementById('mappingForm');
    form.innerHTML = '';

    systemFields.forEach(field => {
        const select = document.createElement('select');
        select.name = field;

        const empty = document.createElement('option');
        empty.value = '';
        empty.text = '-- Select Column --';
        select.appendChild(empty);

        fileColumns.forEach(col => {
            const option = document.createElement('option');
            option.value = col;
            option.text = col;
            select.appendChild(option);
        });

        const label = document.createElement('label');
        label.innerText = field + ': ';

        form.appendChild(label);
        form.appendChild(select);
        form.appendChild(document.createElement('br'));
    });

    document.getElementById('mappingSection').style.display = 'block';
}

function submitMapping() {
    const mapping = {};
    systemFields.forEach(field => {
        const val = document.querySelector(`[name="${field}"]`).value;
        if (val) mapping[field] = val;
    });

    localStorage.setItem('file_token', uploadedFileToken);
    localStorage.setItem('mapping', JSON.stringify(mapping));

    window.location.href = 'preview.html';
}
